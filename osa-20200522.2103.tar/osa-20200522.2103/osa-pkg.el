(define-package "osa" "20200522.2103" "OSA (JavaScript / AppleScript) bridge"
  '((emacs "25.1"))
  :commit "615ca9eef4131a23d9971691fa0d0f20fe59d01b" :authors
  '(("xristos" . "xristos@sdf.org"))
  :maintainer
  '("xristos" . "xristos@sdf.org")
  :keywords
  '("extensions")
  :url "https://github.com/atomontage/osa")
;; Local Variables:
;; no-byte-compile: t
;; End:
