(define-package "octopress" "20190123.107" "A lightweight wrapper for Jekyll and Octopress." 'nil :commit "f2c92d5420f14fc9167c7de1873836510e652de2" :authors
  '(("Aaron Bieber" . "aaron@aaronbieber.com"))
  :maintainer
  '("Aaron Bieber" . "aaron@aaronbieber.com")
  :keywords
  '("octopress" "blog")
  :url "https://github.com/aaronbieber/octopress.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
