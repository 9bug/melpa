(define-package "geiser" "20210404.1448" "GNU Emacs and Scheme talk to each other"
  '((emacs "24.4"))
  :commit "0d90066b211c3e257f736d041805bcf17d7e22be" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@gnu.org"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/")
;; Local Variables:
;; no-byte-compile: t
;; End:
