(define-package "geiser-mit" "20210321.2240" "MIT/GNU Scheme's implementation of the geiser protocols"
  '((emacs "24.4")
    (geiser "0.12"))
  :commit "96845db845b0c6368134ca0e5e5b9dd94b90a832" :authors
  '(("Peter" . "craven@gmx.net"))
  :maintainer
  '("Jose A Ortega Ruiz" . "jao@gnu.org")
  :keywords
  '("languages" "mit" "scheme" "geiser")
  :url "https://gitlab.com/emacs-geiser/mit")
;; Local Variables:
;; no-byte-compile: t
;; End:
