(define-package "dizzee" "20171201.916" "A more pleasant way to manage your project's subprocesses in Emacs." 'nil :commit "e3cf1c2ea5d0fc00747524b6f3c5b905d0a8c8e1" :authors
  '(("David Miller" . "david@deadpansincerity.com"))
  :maintainer
  '("David Miller" . "david@deadpansincerity.com")
  :keywords
  '("emacs" "processes")
  :url "https://github.com/davidmiller/dizzee")
;; Local Variables:
;; no-byte-compile: t
;; End:
