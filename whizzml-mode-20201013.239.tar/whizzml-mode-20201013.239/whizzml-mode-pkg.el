(define-package "whizzml-mode" "20201013.239" "Programming mode for editing WhizzML files"
  '((emacs "24.4"))
  :commit "3dce3be0c32b9b2d259e462b4b27c530af47466a" :authors
  '(("Jose Antonio Ortega Ruiz" . "jao@bigml.com"))
  :maintainer
  '("Jose Antonio Ortega Ruiz" . "jao@bigml.com")
  :keywords
  '("languages" "lisp"))
;; Local Variables:
;; no-byte-compile: t
;; End:
