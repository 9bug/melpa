(define-package "stimmung-themes" "20210331.1140" "Themes tuned to inner harmonies"
  '((emacs "25"))
  :commit "0dc71ec178c3dab8973c90758fa730c70df01554" :authors
  '(("Love Lagerkvist"))
  :maintainer
  '("Love Lagerkvist")
  :keywords
  '("faces")
  :url "https://github.com/motform/stimmung-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
