(define-package "docopt" "20201211.1008" "A Docopt implementation in Elisp"
  '((emacs "26.3")
    (dash "2.17.0")
    (emacs "26.1")
    (f "0.20.0")
    (parsec "0.1.3")
    (s "1.12.0")
    (transient "0.3.0"))
  :commit "6e1105347decbf9b4b848d952858455f9b145c56" :authors
  '(("r0man" . "roman@burningswell.com"))
  :maintainer
  '("r0man" . "roman@burningswell.com")
  :keywords
  '("docopt" "tools" "processes")
  :url "https://github.com/r0man/docopt.el")
;; Local Variables:
;; no-byte-compile: t
;; End:
