(define-package "esonify" "20190110.1621" "Sonify your code"
  '((deferred "0.3.1")
    (cl-lib "0.5"))
  :commit "bdc79d4ab2e3c449b5bef46e5cabc552beeed5c6" :authors
  '(("Oliver Flatt" . "oflatt@gmail.com"))
  :maintainer
  '("Oliver Flatt" . "oflatt@gmail.com")
  :url "https://github.com/oflatt/esonify")
;; Local Variables:
;; no-byte-compile: t
;; End:
