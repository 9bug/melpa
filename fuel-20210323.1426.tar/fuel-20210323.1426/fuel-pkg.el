(define-package "fuel" "20210323.1426" "Major mode for the Factor programming language."
  '((cl-lib "0.2")
    (emacs "24.2"))
  :commit "4f304cbc877b72618ad1b2dba8f9f8c5c3550f7a")
;; Local Variables:
;; no-byte-compile: t
;; End:
