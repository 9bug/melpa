(define-package "parrot" "20191015.2127" "Party Parrot rotates gracefully in mode-line."
  '((emacs "24.1"))
  :commit "29265d118267e524453aaa9121c4eae213a63164" :authors
  '(("Daniel Ting" . "deep.paren.12@gmail.com"))
  :maintainer
  '("Daniel Ting" . "deep.paren.12@gmail.com")
  :keywords
  '("party" "parrot" "rotate" "sirocco" "kakapo" "games")
  :url "https://github.com/dp12/parrot.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
