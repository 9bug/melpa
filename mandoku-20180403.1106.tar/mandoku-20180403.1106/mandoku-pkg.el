(define-package "mandoku" "20180403.1106" "A tool to access repositories of premodern Chinese texts"
  '((org "8")
    (github-clone "20150705.1705"))
  :commit "d65dbaa329ecf931f4142be72862972ea6a24e63" :authors
  '(("Christian Wittern" . "cwittern@gmail.com"))
  :maintainer
  '("Christian Wittern" . "cwittern@gmail.com")
  :keywords
  '("convenience")
  :url "http://www.mandoku.org")
;; Local Variables:
;; no-byte-compile: t
;; End:
