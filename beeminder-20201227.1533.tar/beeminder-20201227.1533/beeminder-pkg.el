(define-package "beeminder" "20201227.1533" "Emacs interface for Beeminder"
  '((emacs "24.3")
    (seq "2.16")
    (org "7"))
  :commit "161d9c94c594614a01cb08219693d9e000af4f69" :authors
  '(("Phil Newton" . "phil@sodaware.net"))
  :maintainer
  '("Phil Newton" . "phil@sodaware.net")
  :keywords
  '("tools" "beeminder")
  :url "http://www.philnewton.net/code/beeminder-el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
