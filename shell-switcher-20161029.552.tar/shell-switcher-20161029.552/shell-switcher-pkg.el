(define-package "shell-switcher" "20161029.552" "Provide fast switching between shell buffers."
  '((emacs "24"))
  :commit "28a7f753dd7addd2933510526f52620cb5a22048" :authors
  '(("Damien Cassou" . "damien.cassou@gmail.com"))
  :maintainer
  '("Damien Cassou" . "damien.cassou@gmail.com")
  :keywords
  '("emacs" "package" "elisp" "shell" "eshell" "term" "switcher")
  :url "https://github.com/DamienCassou/shell-switcher")
;; Local Variables:
;; no-byte-compile: t
;; End:
