(define-package "show-css" "20160210.1408" "Show the css of the html attribute the cursor is on"
  '((doom "1.3")
    (s "1.10.0"))
  :commit "771daeddd4df7a7c10f66419a837145649bab63b" :authors
  '(("Sheldon McGrandle" . "developer@rednemesis.com"))
  :maintainer
  '("Sheldon McGrandle" . "developer@rednemesis.com")
  :keywords
  '("hypermedia")
  :url "https://github.com/smmcg/showcss-mode")
;; Local Variables:
;; no-byte-compile: t
;; End:
