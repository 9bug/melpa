(define-package "zmq" "20210402.2340" "ZMQ bindings in elisp"
  '((cl-lib "0.5")
    (emacs "26"))
  :commit "0a186a732b78aeb86599ea8123b36c4885789c7d" :authors
  '(("Nathaniel Nicandro" . "nathanielnicandro@gmail.com"))
  :maintainer
  '("Nathaniel Nicandro" . "nathanielnicandro@gmail.com")
  :keywords
  '("comm")
  :url "https://github.com/nnicandro/emacs-zmq")
;; Local Variables:
;; no-byte-compile: t
;; End:
