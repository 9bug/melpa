(define-package "modus-themes" "20210405.1553" "Highly accessible themes (WCAG AAA)"
  '((emacs "26.1"))
  :commit "a827453b52ad16abca76ec9792a0b48e4314f79b" :authors
  '(("Protesilaos Stavrou" . "info@protesilaos.com"))
  :maintainer
  '("Protesilaos Stavrou" . "info@protesilaos.com")
  :keywords
  '("faces" "theme" "accessibility")
  :url "https://gitlab.com/protesilaos/modus-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
