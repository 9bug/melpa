(define-package "purp-theme" "20190629.1829" "A dark color theme with few colors" 'nil :commit "f821a7c30452d970ccb0ee08b68d56603860e31d" :authors
  '(("Vincent Foley" . "vfoley@gmail.com"))
  :maintainer
  '("Vincent Foley" . "vfoley@gmail.com")
  :keywords
  '("faces")
  :url "https://github.com/gnuvince/purp")
;; Local Variables:
;; no-byte-compile: t
;; End:
