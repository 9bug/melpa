(define-package "realgud-jdb" "20200722.1120" "Realgud front-end to Java's jdb debugger\""
  '((realgud "1.5.0")
    (load-relative "1.3.1")
    (emacs "25"))
  :commit "1c183b2f8aae0de60942ea01444b896bf182c66a" :authors
  '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainer
  '("Rocky Bernstein" . "rocky@gnu.org")
  :url "https://github.com/realgud/realgud-jdb")
;; Local Variables:
;; no-byte-compile: t
;; End:
