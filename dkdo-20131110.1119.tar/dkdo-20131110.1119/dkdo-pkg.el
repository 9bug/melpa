(define-package "dkdo" "20131110.1119" "Do List major mode based on org-mode."
  '((dkmisc "0.50")
    (emacs "24.1"))
  :commit "fd6bb105e8331fafb6385c5238c988c4c5bbe2da" :authors
  '(("David Keegan" . "dksw@eircom.net"))
  :maintainer
  '("David Keegan" . "dksw@eircom.net")
  :keywords
  '("dolist" "task" "productivity")
  :url "https://github.com/davidkeegan/dkdo")
;; Local Variables:
;; no-byte-compile: t
;; End:
