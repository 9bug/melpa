(define-package "dune" "20210213.757" "Integration with the dune build system" 'nil :commit "bac5860e9844afb8ca30dfdac584ce1db2659c34" :url "https://github.com/ocaml/dune")
;; Local Variables:
;; no-byte-compile: t
;; End:
