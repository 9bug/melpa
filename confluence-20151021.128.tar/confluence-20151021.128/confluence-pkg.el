(define-package "confluence" "20151021.128" "Emacs mode for interacting with confluence wikis"
  '((xml-rpc "1.6.4"))
  :commit "4518d270a07760644c4204985c83d234ece4738b" :authors
  '(("James Ahlborn"))
  :maintainer
  '("James Ahlborn")
  :keywords
  '("confluence" "wiki" "xmlrpc")
  :url "http://code.google.com/p/confluence-el/")
;; Local Variables:
;; no-byte-compile: t
;; End:
