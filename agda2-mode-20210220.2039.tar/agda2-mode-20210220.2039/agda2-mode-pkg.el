(define-package "agda2-mode" "20210220.2039" "interactive development for Agda, a dependently typed functional programming language"
  '((emacs "24.3")
    (annotation "1.0")
    (eri "1.0"))
  :commit "75d82f728dbb65a826e09a37dc313a7a132e1933")
;; Local Variables:
;; no-byte-compile: t
;; End:
