(define-package "timer-revert" "20150122.2032" "minor mode to revert buffer for a given time interval." 'nil :commit "615c91dec8b440d2b9b7c725dd733d7432564e45" :authors
  '(("Yagnesh Raghava Yakkala. http://yagnesh.org"))
  :maintainer
  '(nil . "hi@yagnesh.org")
  :keywords
  '("timer" "revert" "auto-revert.")
  :url "http://github.com/yyr/timer-revert")
;; Local Variables:
;; no-byte-compile: t
;; End:
