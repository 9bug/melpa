(define-package "rcirc-alert" "20141127.1047" "Configurable alert messages on top of RCIRC" 'nil :commit "0adf8ff9c47023fec578f678424be62b0f49057f" :maintainer
  '("Cayetano Santos")
  :keywords
  '("lisp" "rcirc" "irc" "alert" "awesome"))
;; Local Variables:
;; no-byte-compile: t
;; End:
