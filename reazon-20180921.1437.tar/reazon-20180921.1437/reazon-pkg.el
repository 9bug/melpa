(define-package "reazon" "20180921.1437" "miniKanren for Emacs"
  '((emacs "26"))
  :commit "020be6467a83957adcbdcb192b61f2c76a94079b" :authors
  '(("Nick Drozd" . "nicholasdrozd@gmail.com"))
  :maintainer
  '("Nick Drozd" . "nicholasdrozd@gmail.com")
  :keywords
  '("languages" "extensions" "lisp")
  :url "https://github.com/nickdrozd/reazon")
;; Local Variables:
;; no-byte-compile: t
;; End:
