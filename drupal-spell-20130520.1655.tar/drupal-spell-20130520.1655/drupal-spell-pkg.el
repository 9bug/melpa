(define-package "drupal-spell" "20130520.1655" "Aspell extra dictionary for Drupal" 'nil :commit "4087c28c89a884ee050961c57166e6b09085f59d" :authors
  '(("Arne Jørgensen" . "arne@arnested.dk"))
  :maintainer
  '("Arne Jørgensen" . "arne@arnested.dk")
  :keywords
  '("wp")
  :url "https://github.com/arnested/drupal-spell")
;; Local Variables:
;; no-byte-compile: t
;; End:
