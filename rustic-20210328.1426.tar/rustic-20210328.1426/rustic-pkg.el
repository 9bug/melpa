(define-package "rustic" "20210328.1426" "Rust development environment"
  '((emacs "26.1")
    (xterm-color "1.6")
    (dash "2.13.0")
    (s "1.10.0")
    (f "0.18.2")
    (markdown-mode "2.3")
    (spinner "1.7.3")
    (let-alist "1.0.4")
    (seq "2.3")
    (ht "2.0"))
  :commit "07d4d9af2c169d6cce6e2117628dfa3192937fb0" :authors
  '(("Mozilla"))
  :maintainer
  '("Mozilla")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
