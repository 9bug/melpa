(define-package "maces-game" "20170903.1551" "another anagram game."
  '((dash "2.12.0")
    (cl-lib "0.5")
    (emacs "24"))
  :commit "c0fb795f5642467ea528d2f04d904547e8a77ecd" :authors
  '(("Pawel Bokota" . "pawelb.lnx@gmail.com"))
  :maintainer
  '("Pawel Bokota" . "pawelb.lnx@gmail.com")
  :keywords
  '("games" "word games" "anagram")
  :url "https://github.com/pawelbx/anagram-game")
;; Local Variables:
;; no-byte-compile: t
;; End:
