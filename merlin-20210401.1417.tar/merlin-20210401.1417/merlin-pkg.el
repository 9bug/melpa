(define-package "merlin" "20210401.1417" "Mode for Merlin, an assistant for OCaml." 'nil :commit "e576bc75f11323ec8489d2e58a701264f5a7fe0e" :authors
  '(("Frédéric Bour <frederic.bour(_)lakaban.net>"))
  :maintainer
  '("Frédéric Bour <frederic.bour(_)lakaban.net>")
  :keywords
  '("ocaml" "languages")
  :url "https://github.com/ocaml/merlin")
;; Local Variables:
;; no-byte-compile: t
;; End:
