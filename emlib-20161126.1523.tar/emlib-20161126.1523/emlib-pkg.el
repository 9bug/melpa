(define-package "emlib" "20161126.1523" "A Machine Learning library for Emacs"
  '((dash "2.13.0")
    (cl-lib "0.5"))
  :commit "dea2af00f551ea580c641d86dd69219f7d4f3685" :authors
  '(("Narendra Joshi" . "narendraj9@gmail.com"))
  :maintainer
  '("Narendra Joshi" . "narendraj9@gmail.com")
  :keywords
  '("data" "ai" "neural networks" "ml")
  :url "https://github.com/narendraj9/emlib.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
