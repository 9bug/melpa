(define-package "howm" "20210217.1128" "Wiki-like note-taking tool"
  '((cl-lib "0.5"))
  :commit "bac98b873d07baf039fe252b9d67f71c235dca06" :authors
  '(("HIRAOKA Kazuyuki" . "khi@users.osdn.me"))
  :maintainer
  '("HIRAOKA Kazuyuki" . "khi@users.osdn.me")
  :url "https://howm.osdn.jp")
;; Local Variables:
;; no-byte-compile: t
;; End:
