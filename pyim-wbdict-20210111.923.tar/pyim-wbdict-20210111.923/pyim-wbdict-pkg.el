(define-package "pyim-wbdict" "20210111.923" "Some wubi dicts for pyim"
  '((pyim "1.0"))
  :commit "62a1bd8b6070463e872137cf8eba50122b180e2c" :authors
  '(("Feng Shu" . "tumashu@163.com"))
  :maintainer
  '("Feng Shu" . "tumashu@163.com")
  :keywords
  '("convenience" "chinese" "pinyin" "input-method" "complete")
  :url "https://github.com/tumashu/pyim-wbdict")
;; Local Variables:
;; no-byte-compile: t
;; End:
