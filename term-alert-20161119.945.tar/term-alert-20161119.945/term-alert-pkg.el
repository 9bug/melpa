(define-package "term-alert" "20161119.945" "Notifications when commands complete in term.el."
  '((emacs "24.0")
    (term-cmd "1.1")
    (alert "1.1")
    (f "0.18.2"))
  :commit "1166c39cc3fb1cb7808eb8955b7f9f6094a306cd" :authors
  '(("Callum J. Cameron" . "cjcameron7@gmail.com"))
  :maintainer
  '("Callum J. Cameron" . "cjcameron7@gmail.com")
  :keywords
  '("notifications" "processes")
  :url "https://github.com/CallumCameron/term-alert")
;; Local Variables:
;; no-byte-compile: t
;; End:
