(define-package "eide" "20200702.2009" "IDE interface" 'nil :commit "b1dfdaf06b00409250135cb1000beac60c7f659b" :authors
  '(("Cédric Marie" . "cedric@hjuvi.fr.eu.org"))
  :maintainer
  '("Cédric Marie" . "cedric@hjuvi.fr.eu.org")
  :url "https://eide.hjuvi.fr.eu.org/")
;; Local Variables:
;; no-byte-compile: t
;; End:
