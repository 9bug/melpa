(define-package "identica-mode" "20130204.2253" "Major mode API client for status.net open microblogging" 'nil :commit "cf9183ee11ac922e85c7c908f04e2d00b03111b3" :authors
  '(("Gabriel Saldana" . "gsaldana@gmail.com"))
  :maintainer
  '("Gabriel Saldana" . "gsaldana@gmail.com")
  :keywords
  '("identica" "web")
  :url "http://blog.gabrielsaldana.org/identica-mode-for-emacs/")
;; Local Variables:
;; no-byte-compile: t
;; End:
