(define-package "fyure" "20130216.1314" "An interface to fix Japanese hyoki-yure" 'nil :commit "b6977f1eb148e8b63259f7233b55bb050e44d9b8" :authors
  '(("Masafumi Oyamada" . "stillpedant@gmail.com"))
  :maintainer
  '("Masafumi Oyamada" . "stillpedant@gmail.com")
  :keywords
  '("languages"))
;; Local Variables:
;; no-byte-compile: t
;; End:
