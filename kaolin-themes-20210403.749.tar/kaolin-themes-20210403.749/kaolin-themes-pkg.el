(define-package "kaolin-themes" "20210403.749" "A set of eye pleasing themes"
  '((emacs "25.1")
    (autothemer "0.2.2")
    (cl-lib "0.6"))
  :commit "367429c39e330cf2b87e8af0ca7c8883baa21ea3" :authors
  '(("Ogden Webb" . "ogdenwebb@gmail.com"))
  :maintainer
  '("Ogden Webb" . "ogdenwebb@gmail.com")
  :keywords
  '("dark" "light" "teal" "blue" "violet" "purple" "brown" "theme" "faces")
  :url "https://github.com/ogdenwebb/emacs-kaolin-themes")
;; Local Variables:
;; no-byte-compile: t
;; End:
