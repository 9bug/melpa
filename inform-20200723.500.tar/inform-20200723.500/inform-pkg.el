(define-package "inform" "20200723.500" "Symbol links in Info buffers to their help documentation."
  '((emacs "25.1"))
  :commit "8ff0a19a9f40cfa8283da8ed73de94c35a327423" :authors
  '(("H. Dieter Wilhelm" . "dieter@duenenhof-wilhelm.de"))
  :maintainer
  '("H. Dieter Wilhelm")
  :keywords
  '("help" "docs" "convenience")
  :url "https://github.com/dieter-wilhelm/inform")
;; Local Variables:
;; no-byte-compile: t
;; End:
