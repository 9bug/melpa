(define-package "weblorg" "20210308.109" "Static Site Generator for org-mode"
  '((templatel "0.1.5")
    (emacs "26.1"))
  :commit "ad31736a0550006c8b73002013c23ca56a0251c4" :authors
  '(("Lincoln Clarete" . "lincoln@clarete.li"))
  :maintainer
  '("Lincoln Clarete" . "lincoln@clarete.li")
  :url "https://emacs.love/weblorg")
;; Local Variables:
;; no-byte-compile: t
;; End:
