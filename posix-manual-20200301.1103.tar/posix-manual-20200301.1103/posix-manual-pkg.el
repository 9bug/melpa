(define-package "posix-manual" "20200301.1103" "POSIX manual page lookup"
  '((emacs "24"))
  :commit "ebaacd7266ae7a66605317f57b9f42e9cfb2ce1e" :authors
  '(("Lassi Kortela" . "lassi@lassi.io"))
  :maintainer
  '("Lassi Kortela" . "lassi@lassi.io")
  :keywords
  '("languages" "util")
  :url "https://github.com/lassik/emacs-posix-manual")
;; Local Variables:
;; no-byte-compile: t
;; End:
