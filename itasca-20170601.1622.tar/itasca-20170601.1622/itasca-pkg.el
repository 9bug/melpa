(define-package "itasca" "20170601.1622" "Major modes for Itasca software data files."
  '((emacs "24.3"))
  :commit "3d15dd1b70d6db69b0f4758a3e28b8b506cc84ca" :authors
  '(("Jason Furtney" . "jkfurtney@gmail.com"))
  :maintainer
  '("Jason Furtney" . "jkfurtney@gmail.com")
  :keywords
  '("itasca" "flac" "3dec" "udec" "flac3d" "pfc" "pfc2d" "pfc3d" "fish")
  :url "http://github.com/jkfurtney/itasca-emacs/")
;; Local Variables:
;; no-byte-compile: t
;; End:
