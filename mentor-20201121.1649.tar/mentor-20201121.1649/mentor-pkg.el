(define-package "mentor" "20201121.1649" "Frontend for the rTorrent bittorrent client"
  '((xml-rpc "1.6.12")
    (seq "1.11")
    (cl-lib "0.5")
    (async "1.9.3"))
  :commit "aa1eb8a8e7d8c5e5564b08f82130eed0943826bb" :authors
  '(("Stefan Kangas" . "stefankangas@gmail.com"))
  :maintainer
  '("Stefan Kangas" . "stefankangas@gmail.com")
  :keywords
  '("comm" "processes" "bittorrent"))
;; Local Variables:
;; no-byte-compile: t
;; End:
