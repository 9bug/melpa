(define-package "vc-auto-commit" "20210216.1517" "Auto-committing feature for your repository" 'nil :commit "56f478016a541b395092a9d3cdc0da84a37b30a1" :authors
  '(("Sylvain Rousseau <thisirs at gmail dot com>"))
  :maintainer
  '("Sylvain Rousseau <thisirs at gmail dot com>")
  :keywords
  '("vc" "convenience")
  :url "http://github.com/thisirs/vc-auto-commit.git")
;; Local Variables:
;; no-byte-compile: t
;; End:
