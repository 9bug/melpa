(define-package "ten-hundred-mode" "20161028.2236" "use only the ten hundred most usual words"
  '((cl-lib "0.5"))
  :commit "bdcfda49b1819e82d61fe90947e50bb948cf7933")
;; Local Variables:
;; no-byte-compile: t
;; End:
