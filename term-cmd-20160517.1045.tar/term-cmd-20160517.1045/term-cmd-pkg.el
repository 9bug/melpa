(define-package "term-cmd" "20160517.1045" "Send commands from programs running in term.el."
  '((emacs "24.0")
    (dash "2.12.0")
    (f "0.18.2"))
  :commit "552aa58965aab9b78e46934462bafe54c0396ffb" :authors
  '(("Callum J. Cameron" . "cjcameron7@gmail.com"))
  :maintainer
  '("Callum J. Cameron" . "cjcameron7@gmail.com")
  :keywords
  '("processes")
  :url "https://github.com/CallumCameron/term-cmd")
;; Local Variables:
;; no-byte-compile: t
;; End:
