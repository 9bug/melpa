(define-package "forge" "20210405.926" "Access Git forges from Magit."
  '((emacs "25.1")
    (closql "1.0.0")
    (dash "2.14.1")
    (emacsql-sqlite "3.0.0")
    (ghub "20190319")
    (let-alist "1.0.5")
    (magit "20190408")
    (markdown-mode "2.3")
    (transient "0.1.0"))
  :commit "ee87ea45930ae7d5034c906b0a869578a4d0759e" :authors
  '(("Jonas Bernoulli" . "jonas@bernoul.li"))
  :maintainer
  '("Jonas Bernoulli" . "jonas@bernoul.li")
  :keywords
  '("git" "tools" "vc")
  :url "https://github.com/magit/forge")
;; Local Variables:
;; no-byte-compile: t
;; End:
