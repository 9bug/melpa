(define-package "etherpad" "20210401.1213" "Interface to the Etherpad API"
  '((emacs "26.3")
    (request "0.3")
    (let-alist "0.0")
    (websocket "1.12")
    (parsec "0.1")
    (0xc "0.1"))
  :commit "fc7de212b34c34d93f5f0f19af846924404e38ae" :authors
  '(("nik gaffney" . "nik@fo.am"))
  :maintainer
  '("nik gaffney" . "nik@fo.am")
  :keywords
  '("comm" "etherpad" "collaborative editing")
  :url "https://github.com/zzkt/ethermacs")
;; Local Variables:
;; no-byte-compile: t
;; End:
