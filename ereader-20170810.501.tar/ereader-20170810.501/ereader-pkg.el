(define-package "ereader" "20170810.501" "Major mode for reading ebooks with org-mode integration"
  '((emacs "24.4")
    (dash "2.12.1")
    (s "1.10.0")
    (xml+ "0.0.0"))
  :commit "f3bbd3f13195f8fba3e3c880aab0e4c60430dcf3" :authors
  '(("Ben Dean" . "bendean837@gmail.com"))
  :maintainer
  '("Ben Dean" . "bendean837@gmail.com")
  :keywords
  '("epub" "ebook")
  :url "https://github.com/bddean/emacs-ereader")
;; Local Variables:
;; no-byte-compile: t
;; End:
