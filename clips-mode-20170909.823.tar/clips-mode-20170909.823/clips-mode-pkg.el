(define-package "clips-mode" "20170909.823" "Major mode for editing CLIPS code and REPL" 'nil :commit "dd38e2822640a38f7d8bfec4f69d8dd24be27074" :authors
  '(("David E. Young" . "david.young@fnc.fujitsu.com")
    ("Andrey Kotlarski" . "m00naticus@gmail.com")
    ("Grant Rettke" . "grettke@acm.org"))
  :maintainer
  '("Grant Rettke" . "grettke@acm.org")
  :keywords
  '("clips"))
;; Local Variables:
;; no-byte-compile: t
;; End:
