(define-package "aproject" "20190730.152" "Basic project framework for Emacs" 'nil :commit "b534e2a62738ad59a8a3cddd386466c145dad3b2" :authors
  '(("Vietor Liu" . "vietor.liu@gmail.com"))
  :maintainer
  '("Vietor Liu" . "vietor.liu@gmail.com")
  :keywords
  '("environment" "project")
  :url "https://github.com/vietor/aproject")
;; Local Variables:
;; no-byte-compile: t
;; End:
