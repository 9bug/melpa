(define-package "realgud-lldb" "20190912.1335" "Realgud front-end to lldb"
  '((load-relative "1.3.1")
    (realgud "1.5.0")
    (emacs "25"))
  :commit "47cb0178fdde50a9d9151ab45806b41007cd758a" :authors
  '(("Rocky Bernstein" . "rocky@gnu.org"))
  :maintainer
  '("Rocky Bernstein" . "rocky@gnu.org")
  :url "http://github.com/realgud/realgud-lldb")
;; Local Variables:
;; no-byte-compile: t
;; End:
