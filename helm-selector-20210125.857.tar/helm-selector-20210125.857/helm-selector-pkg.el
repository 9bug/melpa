(define-package "helm-selector" "20210125.857" "Helm buffer selector"
  '((emacs "26.1")
    (helm "3"))
  :commit "4da4711c4cfd14527abe20d66787beeb49171b26" :authors
  '(("Pierre Neidhardt" . "mail@ambrevar.xyz"))
  :maintainer
  '("Pierre Neidhardt" . "mail@ambrevar.xyz")
  :url "https://github.com/emacs-helm/helm-selector")
;; Local Variables:
;; no-byte-compile: t
;; End:
