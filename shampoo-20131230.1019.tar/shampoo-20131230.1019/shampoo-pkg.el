(define-package "shampoo" "20131230.1019" "A remote Smalltalk development mode" 'nil :commit "bc193c39636c30182159c5c91c37a9a4cb50fedf")
;; Local Variables:
;; no-byte-compile: t
;; End:
