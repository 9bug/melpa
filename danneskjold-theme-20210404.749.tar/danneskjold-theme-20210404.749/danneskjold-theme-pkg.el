(define-package "danneskjold-theme" "20210404.749" "Beautiful high-contrast Emacs theme." 'nil :commit "e275853832c870e3c1ec09c8f14adda4e0a54633" :authors
  '(("Dmitry Akatov" . "akatovda@yandex.com"))
  :maintainer
  '("Dmitry Akatov" . "akatovda@yandex.com")
  :url "https://github.com/rails-to-cosmos/")
;; Local Variables:
;; no-byte-compile: t
;; End:
