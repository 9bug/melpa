(define-package "projmake-mode" "20161031.1715" "Project oriented automatic builder and error highlighter, flymake for projects"
  '((dash "20150611.922")
    (indicators "20130217.1405"))
  :commit "a897701f7e8f8cc11459ed44eb0e454db2a460c1")
;; Local Variables:
;; no-byte-compile: t
;; End:
