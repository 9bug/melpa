(define-package "docstr" "20210317.1612" "A document string minor mode"
  '((emacs "24.4")
    (s "1.9.0"))
  :commit "5ce0d758dbabb6c250f761fcb6754930cd793c2a" :authors
  '(("Shen, Jen-Chieh" . "jcs090218@gmail.com"))
  :maintainer
  '("Shen, Jen-Chieh" . "jcs090218@gmail.com")
  :url "https://github.com/jcs-elpa/docstr")
;; Local Variables:
;; no-byte-compile: t
;; End:
