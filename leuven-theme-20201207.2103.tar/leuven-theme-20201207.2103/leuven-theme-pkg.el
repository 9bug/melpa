(define-package "leuven-theme" "20201207.2103" "Awesome Emacs color theme on white background" 'nil :commit "a1154d65bf33ae34ea944b9e59d95b601fea7169" :authors
  '(("Fabrice Niessen <(concat \"fniessen\" at-sign \"pirilampo.org\")>"))
  :maintainer
  '("Fabrice Niessen <(concat \"fniessen\" at-sign \"pirilampo.org\")>")
  :keywords
  '("color" "theme")
  :url "https://github.com/fniessen/emacs-leuven-theme")
;; Local Variables:
;; no-byte-compile: t
;; End:
