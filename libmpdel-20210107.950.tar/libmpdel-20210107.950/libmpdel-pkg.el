(define-package "libmpdel" "20210107.950" "Communication with an MPD server"
  '((emacs "25.1"))
  :commit "9162a4b350c978f94dde6f75d60bc6a17e1dc18e" :authors
  '(("Damien Cassou" . "damien@cassou.me"))
  :maintainer
  '("Damien Cassou" . "damien@cassou.me")
  :keywords
  '("multimedia")
  :url "https://gitea.petton.fr/mpdel/libmpdel")
;; Local Variables:
;; no-byte-compile: t
;; End:
