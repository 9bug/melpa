(define-package "mb-url" "20191006.1930" "Multiple Backends for Emacs URL package."
  '((cl-lib "0"))
  :commit "7230902e1f844e0a1388f741e9ae6260cda3de69" :authors
  '(("ZHANG Weiyi" . "dochang@gmail.com"))
  :maintainer
  '("ZHANG Weiyi" . "dochang@gmail.com"))
;; Local Variables:
;; no-byte-compile: t
;; End:
