(define-package "emacsshot" "20191206.944" "Snapshot a frame or window from within"
  '((emacs "24.4"))
  :commit "fe958b11056f3c671ebdd604d5aa574323284ca5" :authors
  '(("Marco Wahl" . "marcowahlsoft@gmail.com"))
  :maintainer
  '("Marco Wahl")
  :keywords
  '("convenience")
  :url "https://gitlab.com/marcowahl/emacsshot")
;; Local Variables:
;; no-byte-compile: t
;; End:
