(define-package "mybigword" "20201030.1253" "Vocabulary builder using Zipf to extract English big words"
  '((emacs "25.1"))
  :commit "4c1386252444df2ade734e02078069a06f3f0f97" :authors
  '(("Chen Bin <chenbin DOT sh AT gmail.com>"))
  :maintainer
  '("Chen Bin <chenbin DOT sh AT gmail.com>")
  :keywords
  '("convenience")
  :url "https://github.com/redguardtoo/mybigword")
;; Local Variables:
;; no-byte-compile: t
;; End:
