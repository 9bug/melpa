(define-package "paperless" "20201130.1241" "A major mode for sorting and filing PDF documents."
  '((emacs "24.4")
    (f "0.11.0")
    (s "1.10.0")
    (cl-lib "0.6.1"))
  :commit "2db39586a2914f78f345379511d0e8cea4c96b86" :authors
  '(("Anthony Green" . "green@moxielogic.com"))
  :maintainer
  '("Anthony Green" . "green@moxielogic.com")
  :keywords
  '("pdf" "convenience")
  :url "http://github.com/atgreen/paperless")
;; Local Variables:
;; no-byte-compile: t
;; End:
