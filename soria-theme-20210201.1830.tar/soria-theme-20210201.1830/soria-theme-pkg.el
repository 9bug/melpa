(define-package "soria-theme" "20210201.1830" "A xoria256 theme with some colors from openSUSE"
  '((emacs "25.1"))
  :commit "f765f193ccaf4ad438e1d9be842efd2f4394efa4" :authors
  '(("Miquel Sabaté Solà" . "mikisabate@gmail.com"))
  :maintainer
  '("Miquel Sabaté Solà" . "mikisabate@gmail.com")
  :keywords
  '("faces")
  :url "https://github.com/mssola/soria")
;; Local Variables:
;; no-byte-compile: t
;; End:
