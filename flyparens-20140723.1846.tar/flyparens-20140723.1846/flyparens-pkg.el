(define-package "flyparens" "20140723.1846" "Check for unbalanced parens on the fly" 'nil :commit "af9b8cfd647d0e5f97684d613dc2eea7cfc19398" :authors
  '(("Jisang Yoo"))
  :maintainer
  '("Jisang Yoo")
  :keywords
  '("faces" "convenience" "lisp" "matching" "parentheses" "parens"))
;; Local Variables:
;; no-byte-compile: t
;; End:
