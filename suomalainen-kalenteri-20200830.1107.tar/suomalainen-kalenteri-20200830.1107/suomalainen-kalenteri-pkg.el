(define-package "suomalainen-kalenteri" "20200830.1107" "Finnish national and Christian holidays for calendar" 'nil :commit "5b209ff7b7d3dcd09b623915aba1e137c875fa0e" :authors
  '(("Teemu Likonen" . "tlikonen@iki.fi"))
  :maintainer
  '("Teemu Likonen" . "tlikonen@iki.fi")
  :keywords
  '("calendar" "holidays" "finnish")
  :url "https://github.com/tlikonen/suomalainen-kalenteri")
;; Local Variables:
;; no-byte-compile: t
;; End:
